#include "EducationShield.h"

TiltSwitch::TiltSwitch(int pin, bool pressedValue):Button(pin,pressedValue){

}
