#include "MosFet.h"
#include "EduIntro.h"

MosFet::MosFet(uint8_t _pin) : Output(_pin) {}
